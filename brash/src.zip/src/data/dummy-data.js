import Item from "../model/productModel";

export const ITEM_LIST = [
  new Item(
    "p1",
    "Kinsmart Die-Cast Metal",
    "https://m.media-amazon.com/images/I/41vkF5Mzn0L._AC_UL320_.jpg",
    220,
    false
  ),
  new Item(
    "p2",
    "D Transperent Mechanical",
    "https://m.media-amazon.com/images/I/61TPVpdvWTL._AC_UL320_.jpg",
    220,
    false
  ),
  new Item(
    "p3",
    "Centy Toys Police Interceptor",
    "https://m.media-amazon.com/images/I/513pe-dIE7L._AC_UL320_.jpg",
    220,
    false
  ),
  new Item(
    "p4",
    "Negi Kinsmart Car",
    "https://m.media-amazon.com/images/I/61EVeL8xYUL._AC_UL320_.jpg",
    220,
    false
  ),
];
