import React, { Component } from "react";

class Favourities extends Component {
  state = {};

  render() {
    return (
      <div>
       Favourities Page
      </div>
    );
  }
}

export default Favourities;